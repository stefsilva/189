import { Component } from '@angular/core';

@Component({
  selector: 'app-formulario-paciente',
  standalone: true,
  imports: [],
  templateUrl: './formulario-paciente.component.html',
  styleUrl: './formulario-paciente.component.css',
})
export class FormularioPacienteComponent {}
