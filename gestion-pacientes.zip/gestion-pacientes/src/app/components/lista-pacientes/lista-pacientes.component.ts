import { Component } from '@angular/core';

@Component({
  selector: 'app-lista-pacientes',
  standalone: true,
  imports: [],
  templateUrl: './lista-pacientes.component.html',
  styleUrl: './lista-pacientes.component.css'
})
export class ListaPacientesComponent {

}
