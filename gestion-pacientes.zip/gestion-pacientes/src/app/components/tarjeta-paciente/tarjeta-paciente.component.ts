import { Component } from '@angular/core';

@Component({
  selector: 'app-tarjeta-paciente',
  standalone: true,
  imports: [],
  templateUrl: './tarjeta-paciente.component.html',
  styleUrl: './tarjeta-paciente.component.css'
})
export class TarjetaPacienteComponent {

}
