export interface Paciente {}
